import sys
sys.path.append('..')
sys.path.insert(1, '/home/cc/ee106a/fa18/class/ee106a-abh/.local/lib/python3.4/site-packages')
import cv2
from pylab import imshow, gray, show
import os
from read import *
from keras.applications.resnet50 import ResNet50
from keras.preprocessing import image
from keras.applications.resnet50 import preprocess_input, decode_predictions
import numpy as np

model = ResNet50(weights='imagenet')

def check_if_chessboard():
	#Use RESNET here to figure out if a board is there or not
	img_path = 'newunprocessedboard.jpg'
	img = image.load_img(img_path, target_size=(224, 224))
	x = image.img_to_array(img)
	x = np.expand_dims(x, axis=0)
	x = preprocess_input(x)

	preds = model.predict(x)

	predicted = decode_predictions(preds, top=10)[0]
	print('Predicted:', predicted)
	chessboard_present = False
	for i in predicted:
		if('crossword_puzzle' in i or 'toilet_seat' in i or 'radiator' in i):
			chessboard_present = True
	return chessboard_present

def capture_image():
	sucess = False
	while(not sucess):
		cv2.namedWindow("preview")
		vc = cv2.VideoCapture(1)

		rval = False 
		while not rval:
			if vc.isOpened(): # try to get the first frame
			    rval, frame = vc.read()
			else:
			    rval = False

		print("Hello welcome please press escape when the camera is pointed to the chessboard to capture the first image")

		super_frame = None
		while rval:
		    cv2.imshow("preview", frame)
		    rval, frame = vc.read()
		    key = cv2.waitKey(20)
		    if key == 27: # exit on ESC
		        super_frame = frame
		        break

		cv2.destroyWindow("preview")
		imshow(super_frame)
		show()

		import subprocess
		cv2.imwrite('newunprocessedboard.jpg', super_frame)
		if(not check_if_chessboard()):
			play('taking_image_error.mp3')
		else:
			subprocess.check_output(["mv","newunprocessedboard.jpg","neural-chessboard"])
			print("Now processing the board...processing....processing")
			try:
				os.chdir('neural-chessboard')
				print("Running neural net now......")
				subprocess.check_output(["python3", "main.py", "--input",'newunprocessedboard.jpg',"--output","board.jpg","detect"])
				subprocess.check_output(["mv","board.jpg",".."])
				os.chdir('..')
				sucess = True
			except Exception as e:
				play('taking_image_error.mp3')

	print("Finished neural net presenting board to get approval from user")
	play('finished_taking_image.mp3')
	return
