from time import time

NC_LAYER = 0
NC_IMAGE = object
NC_CLOCK = time()
NC_DEBUG = False # True

NC_CONFIG = {'layers': 3}
